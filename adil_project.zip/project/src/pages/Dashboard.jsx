import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { statisticsAPI } from '../services/api';
import { 
  TrendingUp, 
  ShoppingCart, 
  DollarSign, 
  Package,
  Receipt,
  BarChart3,
  PlusCircle,
  Users
} from 'lucide-react';

const Dashboard = () => {
  const { user } = useAuth();
  const [statistics, setStatistics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const currentMonth = new Date().getMonth() + 1;

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        const response = await statisticsAPI.getStatistics(currentMonth);
        setStatistics(response.data);
      } catch (error) {
        console.error('Dashboard data fetch error:', error);
        setError('Failed to load dashboard data');
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, [currentMonth]);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const monthName = new Date(2023, currentMonth - 1).toLocaleString('default', { month: 'long' });

  const quickActions = [
    {
      title: 'View Transactions',
      description: 'Browse and search all transactions',
      icon: Receipt,
      link: '/transactions',
      color: 'bg-blue-500 hover:bg-blue-600',
      roles: ['admin', 'store_owner', 'user']
    },
    {
      title: 'View Statistics',
      description: 'Analyze transaction statistics and charts',
      icon: BarChart3,
      link: '/statistics',
      color: 'bg-green-500 hover:bg-green-600',
      roles: ['admin', 'store_owner', 'user']
    },
    {
      title: 'Add Transaction',
      description: 'Create a new transaction record',
      icon: PlusCircle,
      link: '/create-transaction',
      color: 'bg-purple-500 hover:bg-purple-600',
      roles: ['admin', 'store_owner']
    },
  ];

  const filteredActions = quickActions.filter(action => 
    action.roles.includes(user?.role)
  );

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-pulse space-y-8">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="text-center lg:text-left">
        <h1 className="text-3xl font-bold text-gray-900">
          {getGreeting()}, {user?.username}!
        </h1>
        <p className="mt-2 text-gray-600">
          Welcome to your transaction management dashboard
        </p>
      </div>

      {/* Statistics Cards */}
      {statistics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Sales ({monthName})</p>
                <p className="text-2xl font-bold text-gray-900">
                  ${statistics.totalSaleAmount.toLocaleString()}
                </p>
              </div>
              <div className="p-3 bg-green-100 rounded-full">
                <DollarSign className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Sold Items</p>
                <p className="text-2xl font-bold text-gray-900">
                  {statistics.totalSoldItems}
                </p>
              </div>
              <div className="p-3 bg-blue-100 rounded-full">
                <ShoppingCart className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Unsold Items</p>
                <p className="text-2xl font-bold text-gray-900">
                  {statistics.totalNotSoldItems}
                </p>
              </div>
              <div className="p-3 bg-orange-100 rounded-full">
                <Package className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Transactions</p>
                <p className="text-2xl font-bold text-gray-900">
                  {statistics.totalTransactions}
                </p>
              </div>
              <div className="p-3 bg-purple-100 rounded-full">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      {/* Quick Actions */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredActions.map((action, index) => (
            <Link
              key={index}
              to={action.link}
              className="group block p-6 bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200"
            >
              <div className="flex items-center space-x-4">
                <div className={`p-3 rounded-lg ${action.color} transition-colors duration-200`}>
                  <action.icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-medium text-gray-900 group-hover:text-blue-600 transition-colors duration-200">
                    {action.title}
                  </h3>
                  <p className="text-sm text-gray-500 mt-1">
                    {action.description}
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Role-specific Information */}
      <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl p-6 border border-blue-100">
        <div className="flex items-start space-x-4">
          <div className="p-3 bg-blue-100 rounded-full">
            <Users className="w-6 h-6 text-blue-600" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-medium text-gray-900">
              {user?.role === 'admin' && 'System Administrator'}
              {user?.role === 'store_owner' && 'Store Owner'}
              {user?.role === 'user' && 'Regular User'}
            </h3>
            <div className="mt-2 text-sm text-gray-600">
              {user?.role === 'admin' && (
                <ul className="space-y-1">
                  <li>• Full access to all transactions and statistics</li>
                  <li>• Can create, update, and delete transactions</li>
                  <li>• Access to system-wide analytics and reports</li>
                </ul>
              )}
              {user?.role === 'store_owner' && (
                <ul className="space-y-1">
                  <li>• Can create and update transactions</li>
                  <li>• View statistics and analytics</li>
                  <li>• Manage store inventory and sales</li>
                </ul>
              )}
              {user?.role === 'user' && (
                <ul className="space-y-1">
                  <li>• View all transactions with search and filters</li>
                  <li>• Access to statistics and charts</li>
                  <li>• Read-only access to system data</li>
                </ul>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;