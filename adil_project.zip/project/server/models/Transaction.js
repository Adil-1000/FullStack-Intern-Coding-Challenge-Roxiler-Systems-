import mongoose from 'mongoose';

const transactionSchema = new mongoose.Schema({
  id: {
    type: Number,
    required: true,
    unique: true
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true,
    trim: true
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  category: {
    type: String,
    required: true,
    trim: true
  },
  image: {
    type: String,
    required: true
  },
  sold: {
    type: Boolean,
    required: true,
    default: false
  },
  dateOfSale: {
    type: Date,
    required: true
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: false
  }
}, {
  timestamps: true
});

// Index for better query performance
transactionSchema.index({ title: 'text', description: 'text' });
transactionSchema.index({ category: 1 });
transactionSchema.index({ dateOfSale: 1 });
transactionSchema.index({ sold: 1 });
transactionSchema.index({ price: 1 });

export default mongoose.model('Transaction', transactionSchema);