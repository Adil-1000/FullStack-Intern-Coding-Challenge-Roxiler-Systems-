import mongoose from 'mongoose';
import axios from 'axios';
import dotenv from 'dotenv';
import Transaction from './models/Transaction.js';
import User from './models/User.js';

dotenv.config();

const seedDatabase = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/roxiler_transactions');
    console.log('✅ Connected to MongoDB for seeding');

    // Clear existing data
    await Transaction.deleteMany({});
    console.log('🗑️  Cleared existing transactions');

    // Create default admin user if not exists
    const adminExists = await User.findOne({ email: 'admin@roxiler.com' });
    if (!adminExists) {
      const admin = new User({
        username: 'admin',
        email: 'admin@roxiler.com',
        password: 'admin123',
        role: 'admin'
      });
      await admin.save();
      console.log('👤 Created default admin user');
    }

    // Create default store owner if not exists
    const storeOwnerExists = await User.findOne({ email: 'store@roxiler.com' });
    if (!storeOwnerExists) {
      const storeOwner = new User({
        username: 'storeowner',
        email: 'store@roxiler.com',
        password: 'store123',
        role: 'store_owner'
      });
      await storeOwner.save();
      console.log('🏪 Created default store owner user');
    }

    // Create default regular user if not exists
    const userExists = await User.findOne({ email: 'user@roxiler.com' });
    if (!userExists) {
      const user = new User({
        username: 'user',
        email: 'user@roxiler.com',
        password: 'user123',
        role: 'user'
      });
      await user.save();
      console.log('👥 Created default user');
    }

    // Fetch data from third-party API
    console.log('📡 Fetching data from third-party API...');
    const response = await axios.get(process.env.SEED_API_URL || 'https://s3.amazonaws.com/roxiler.com/product_transaction.json');
    const transactions = response.data;

    console.log(`📦 Received ${transactions.length} transactions`);

    // Insert transactions
    await Transaction.insertMany(transactions);
    console.log('✅ Successfully seeded transaction data');

    // Display summary
    const totalTransactions = await Transaction.countDocuments();
    const soldTransactions = await Transaction.countDocuments({ sold: true });
    const categories = await Transaction.distinct('category');
    
    console.log('\n📊 Seeding Summary:');
    console.log(`   Total Transactions: ${totalTransactions}`);
    console.log(`   Sold Items: ${soldTransactions}`);
    console.log(`   Unsold Items: ${totalTransactions - soldTransactions}`);
    console.log(`   Categories: ${categories.length}`);
    console.log(`   Category List: ${categories.join(', ')}`);

    console.log('\n👤 Default Users Created:');
    console.log('   Admin: admin@roxiler.com / admin123');
    console.log('   Store Owner: store@roxiler.com / store123');
    console.log('   User: user@roxiler.com / user123');

    process.exit(0);
  } catch (error) {
    console.error('❌ Seeding failed:', error);
    process.exit(1);
  }
};

seedDatabase();