import express from 'express';
import Transaction from '../models/Transaction.js';
import { authenticateToken, authorizeRoles } from '../middleware/auth.js';

const router = express.Router();

// Get all transactions with search and pagination
router.get('/', authenticateToken, async (req, res) => {
  try {
    const {
      search = '',
      page = 1,
      perPage = 10,
      month,
      category,
      sold
    } = req.query;

    const pageNum = parseInt(page);
    const limitNum = parseInt(perPage);
    const skip = (pageNum - 1) * limitNum;

    // Build query
    let query = {};

    // Search functionality
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { category: { $regex: search, $options: 'i' } }
      ];
    }

    // Filter by month
    if (month) {
      const monthNum = parseInt(month);
      query.$expr = {
        $eq: [{ $month: '$dateOfSale' }, monthNum]
      };
    }

    // Filter by category
    if (category) {
      query.category = { $regex: category, $options: 'i' };
    }

    // Filter by sold status
    if (sold !== undefined) {
      query.sold = sold === 'true';
    }

    const transactions = await Transaction.find(query)
      .sort({ dateOfSale: -1 })
      .skip(skip)
      .limit(limitNum);

    const total = await Transaction.countDocuments(query);

    res.json({
      transactions,
      pagination: {
        currentPage: pageNum,
        perPage: limitNum,
        totalPages: Math.ceil(total / limitNum),
        totalRecords: total,
        hasNextPage: pageNum < Math.ceil(total / limitNum),
        hasPrevPage: pageNum > 1
      }
    });
  } catch (error) {
    console.error('Get transactions error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single transaction
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const transaction = await Transaction.findOne({ id: req.params.id });
    
    if (!transaction) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    res.json(transaction);
  } catch (error) {
    console.error('Get transaction error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create new transaction (Store Owner and Admin only)
router.post('/', authenticateToken, authorizeRoles('store_owner', 'admin'), async (req, res) => {
  try {
    const {
      title,
      description,
      price,
      category,
      image,
      sold = false,
      dateOfSale
    } = req.body;

    // Validation
    if (!title || !description || !price || !category || !image || !dateOfSale) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    if (price < 0) {
      return res.status(400).json({ error: 'Price cannot be negative' });
    }

    // Get next ID
    const lastTransaction = await Transaction.findOne().sort({ id: -1 });
    const nextId = lastTransaction ? lastTransaction.id + 1 : 1;

    const transaction = new Transaction({
      id: nextId,
      title,
      description,
      price: parseFloat(price),
      category,
      image,
      sold: Boolean(sold),
      dateOfSale: new Date(dateOfSale),
      createdBy: req.user._id
    });

    await transaction.save();

    res.status(201).json({
      message: 'Transaction created successfully',
      transaction
    });
  } catch (error) {
    console.error('Create transaction error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update transaction (Store Owner and Admin only)
router.put('/:id', authenticateToken, authorizeRoles('store_owner', 'admin'), async (req, res) => {
  try {
    const {
      title,
      description,
      price,
      category,
      image,
      sold,
      dateOfSale
    } = req.body;

    const updateData = {};
    if (title !== undefined) updateData.title = title;
    if (description !== undefined) updateData.description = description;
    if (price !== undefined) {
      if (price < 0) {
        return res.status(400).json({ error: 'Price cannot be negative' });
      }
      updateData.price = parseFloat(price);
    }
    if (category !== undefined) updateData.category = category;
    if (image !== undefined) updateData.image = image;
    if (sold !== undefined) updateData.sold = Boolean(sold);
    if (dateOfSale !== undefined) updateData.dateOfSale = new Date(dateOfSale);

    const transaction = await Transaction.findOneAndUpdate(
      { id: req.params.id },
      updateData,
      { new: true, runValidators: true }
    );

    if (!transaction) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    res.json({
      message: 'Transaction updated successfully',
      transaction
    });
  } catch (error) {
    console.error('Update transaction error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete transaction (Admin only)
router.delete('/:id', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const transaction = await Transaction.findOneAndDelete({ id: req.params.id });

    if (!transaction) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    res.json({ message: 'Transaction deleted successfully' });
  } catch (error) {
    console.error('Delete transaction error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;