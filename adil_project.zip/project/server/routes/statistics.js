import express from 'express';
import Transaction from '../models/Transaction.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Get statistics for a specific month
router.get('/:month', authenticateToken, async (req, res) => {
  try {
    const month = parseInt(req.params.month);
    
    if (month < 1 || month > 12) {
      return res.status(400).json({ error: 'Month must be between 1 and 12' });
    }

    // Get transactions for the specific month
    const monthTransactions = await Transaction.find({
      $expr: { $eq: [{ $month: '$dateOfSale' }, month] }
    });

    const soldItems = monthTransactions.filter(t => t.sold);
    const notSoldItems = monthTransactions.filter(t => !t.sold);

    const totalSaleAmount = soldItems.reduce((sum, item) => sum + item.price, 0);

    const statistics = {
      totalSaleAmount: parseFloat(totalSaleAmount.toFixed(2)),
      totalSoldItems: soldItems.length,
      totalNotSoldItems: notSoldItems.length,
      totalTransactions: monthTransactions.length
    };

    res.json(statistics);
  } catch (error) {
    console.error('Statistics error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get bar chart data for price ranges
router.get('/barchart/:month', authenticateToken, async (req, res) => {
  try {
    const month = parseInt(req.params.month);
    
    if (month < 1 || month > 12) {
      return res.status(400).json({ error: 'Month must be between 1 and 12' });
    }

    const monthTransactions = await Transaction.find({
      $expr: { $eq: [{ $month: '$dateOfSale' }, month] }
    });

    const priceRanges = {
      '0-100': 0,
      '101-200': 0,
      '201-300': 0,
      '301-400': 0,
      '401-500': 0,
      '501-600': 0,
      '601-700': 0,
      '701-800': 0,
      '801-900': 0,
      '901-above': 0
    };

    monthTransactions.forEach(transaction => {
      const price = transaction.price;
      if (price <= 100) priceRanges['0-100']++;
      else if (price <= 200) priceRanges['101-200']++;
      else if (price <= 300) priceRanges['201-300']++;
      else if (price <= 400) priceRanges['301-400']++;
      else if (price <= 500) priceRanges['401-500']++;
      else if (price <= 600) priceRanges['501-600']++;
      else if (price <= 700) priceRanges['601-700']++;
      else if (price <= 800) priceRanges['701-800']++;
      else if (price <= 900) priceRanges['801-900']++;
      else priceRanges['901-above']++;
    });

    res.json(priceRanges);
  } catch (error) {
    console.error('Bar chart error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get pie chart data for categories
router.get('/piechart/:month', authenticateToken, async (req, res) => {
  try {
    const month = parseInt(req.params.month);
    
    if (month < 1 || month > 12) {
      return res.status(400).json({ error: 'Month must be between 1 and 12' });
    }

    const categoryData = await Transaction.aggregate([
      {
        $match: {
          $expr: { $eq: [{ $month: '$dateOfSale' }, month] }
        }
      },
      {
        $group: {
          _id: '$category',
          count: { $sum: 1 }
        }
      },
      {
        $sort: { count: -1 }
      }
    ]);

    const result = {};
    categoryData.forEach(item => {
      result[item._id] = item.count;
    });

    res.json(result);
  } catch (error) {
    console.error('Pie chart error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get combined data (statistics + bar chart + pie chart)
router.get('/combined/:month', authenticateToken, async (req, res) => {
  try {
    const month = parseInt(req.params.month);
    
    if (month < 1 || month > 12) {
      return res.status(400).json({ error: 'Month must be between 1 and 12' });
    }

    // Get all data in parallel for better performance
    const monthTransactions = await Transaction.find({
      $expr: { $eq: [{ $month: '$dateOfSale' }, month] }
    });

    // Statistics
    const soldItems = monthTransactions.filter(t => t.sold);
    const notSoldItems = monthTransactions.filter(t => !t.sold);
    const totalSaleAmount = soldItems.reduce((sum, item) => sum + item.price, 0);

    const statistics = {
      totalSaleAmount: parseFloat(totalSaleAmount.toFixed(2)),
      totalSoldItems: soldItems.length,
      totalNotSoldItems: notSoldItems.length,
      totalTransactions: monthTransactions.length
    };

    // Bar chart data
    const priceRanges = {
      '0-100': 0,
      '101-200': 0,
      '201-300': 0,
      '301-400': 0,
      '401-500': 0,
      '501-600': 0,
      '601-700': 0,
      '701-800': 0,
      '801-900': 0,
      '901-above': 0
    };

    monthTransactions.forEach(transaction => {
      const price = transaction.price;
      if (price <= 100) priceRanges['0-100']++;
      else if (price <= 200) priceRanges['101-200']++;
      else if (price <= 300) priceRanges['201-300']++;
      else if (price <= 400) priceRanges['301-400']++;
      else if (price <= 500) priceRanges['401-500']++;
      else if (price <= 600) priceRanges['501-600']++;
      else if (price <= 700) priceRanges['601-700']++;
      else if (price <= 800) priceRanges['701-800']++;
      else if (price <= 900) priceRanges['801-900']++;
      else priceRanges['901-above']++;
    });

    // Pie chart data
    const categoryCount = {};
    monthTransactions.forEach(transaction => {
      categoryCount[transaction.category] = (categoryCount[transaction.category] || 0) + 1;
    });

    res.json({
      statistics,
      barChart: priceRanges,
      pieChart: categoryCount,
      monthName: new Date(2023, month - 1).toLocaleString('default', { month: 'long' })
    });
  } catch (error) {
    console.error('Combined data error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;